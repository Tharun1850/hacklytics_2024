export type message = {
    avatarSource: string;
    avatarFallback: string;
    name: string;
    message: string;
  }
