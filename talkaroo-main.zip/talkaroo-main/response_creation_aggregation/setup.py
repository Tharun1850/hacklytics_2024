from setuptools import setup

setup(name='endpoint',
      version='0.1',
      description='Talkaroo Chat Endpoint',
      # url='http://github.com/storborg/funniest',
      # author='Flying Circus',
      # author_email='flyingcircus@example.com',
      # license='MIT',
      packages=['endpoint'],
      # zip_safe=False,
      )